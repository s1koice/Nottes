
import React, { useEffect, useMemo, useState } from 'react'
import { db, Note } from './db'
import { SearchBar } from './components/SearchBar'
import { NoteList } from './components/NoteList'
import { Editor } from './components/Editor'
import { extractWikiLinks, stripHtml } from './utils'
import './styles.css'

function uid(){ return Math.random().toString(36).slice(2) }

export default function App(){
  const [notes, setNotes] = useState<Note[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [tagFilter, setTagFilter] = useState<string | null>(null)

  async function refresh(){
    const all = await db.notes.orderBy('updatedAt').reverse().toArray()
    setNotes(all)
    if (!activeId && all[0]) setActiveId(all[0].id)
  }

  useEffect(()=>{ refresh() }, [])

  useEffect(() => {
    const h = setInterval(refresh, 1000) // cheap polling for demo
    return () => clearInterval(h)
  }, [activeId])

  const activeNote = useMemo(() => notes.find(n => n.id === activeId) || null, [notes, activeId])

  async function createNote(){
    const id = uid()
    const now = Date.now()
    const note: Note = { id, title: 'Новая заметка', html: '<p><br></p>', tags: [], createdAt: now, updatedAt: now }
    await db.notes.add(note)
    await refresh()
    setActiveId(id)
  }

  async function deleteNote(id: string){
    await db.notes.delete(id)
    await refresh()
    setActiveId(notes[0]?.id || null)
  }

  async function savePartial(p: Partial<Note>){
    if (!activeNote) return
    const html = p.html ?? activeNote.html
    const title = (p.title ?? activeNote.title).trim()
    const tags = p.tags ?? activeNote.tags
    const updatedAt = Date.now()
    await db.notes.update(activeNote.id, { html, title, tags, updatedAt })
    await refresh()
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return notes
    return notes.filter(n => {
      const text = (n.title + ' ' + n.html.replace(/<[^>]+>/g,' ')).toLowerCase()
      return text.includes(q) || n.tags.some(t => t.includes(q))
    })
  }, [notes, query])

  // Backlinks: find notes that mention [[This Title]] or [[id:...]]
  const backlinks = useMemo(() => {
    if (!activeNote) return []
    const title = activeNote.title
    const id = activeNote.id
    return notes.filter(n => n.id !== id && (n.html.includes(`[[${title}]]`) || n.html.includes(`[[id:${id}]]`)))
  }, [notes, activeNote])

  const allTags = useMemo(() => {
    const set = new Set<string>()
    notes.forEach(n => n.tags.forEach(t => set.add(t)))
    return Array.from(set).sort()
  }, [notes])

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="top">
          <button onClick={createNote}>＋ Новая</button>
          <button onClick={() => setTagFilter(null)} title="Сбросить фильтр">🏷️</button>
        </div>
        <div style={{padding: '8px', display:'flex', gap:8, flexWrap:'wrap'}}>
          {allTags.map(t => (
            <button key={t} className="tag" onClick={()=>setTagFilter(t)}>#{t}</button>
          ))}
        </div>
        <div style={{padding: '8px'}}>
          <SearchBar value={query} onChange={setQuery} />
        </div>
        <NoteList notes={filtered} activeId={activeId || undefined} onOpen={setActiveId} query={query} tagFilter={tagFilter} />
      </aside>
      <main className="content">
        {activeNote ? (
          <>
            <Editor note={activeNote} onChange={savePartial} />
            <div className="editor-wrap">
              <div className="backlinks">
                <div style={{fontWeight:600, marginBottom:6}}>Ссылки на эту заметку</div>
                {backlinks.length === 0 ? <div className="meta">Пока нет</div> : (
                  <div style={{display:'flex', gap:8, flexDirection:'column'}}>
                    {backlinks.map(b => (
                      <div key={b.id} className="note-item" onClick={()=>setActiveId(b.id)}>
                        <div className="note-title">{b.title || 'Без названия'}</div>
                        <div className="note-snippet">{stripHtml(b.html).slice(0,120)}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div className="footer">
              <div>[[Wiki Links]] · #теги · ⌘/Ctrl+B/I/U</div>
              <button onClick={()=>deleteNote(activeNote.id)} style={{color:'#b91c1c'}}>Удалить</button>
            </div>
          </>
        ) : (
          <div className="editor-wrap">
            <div className="meta">Нет открытой заметки</div>
            <button onClick={createNote}>Создать первую заметку</button>
          </div>
        )}
      </main>
    </div>
  )
}
