
// Extract #tags and [[Wiki Links]] from plain text (or from textContent of HTML)
export function extractTags(text: string): string[] {
  const set = new Set<string>()
  const tagRegex = /(^|\s)#([\p{L}\p{N}_-]+)/gu
  let m
  while ((m = tagRegex.exec(text))) {
    set.add(m[2].toLowerCase())
  }
  return Array.from(set)
}

export function extractWikiLinks(text: string): string[] {
  const set = new Set<string>()
  const re = /\[\[([^\]]+)\]\]/g
  let m
  while ((m = re.exec(text))) {
    set.add(m[1])
  }
  return Array.from(set)
}

export function stripHtml(html: string): string {
  const div = document.createElement('div')
  div.innerHTML = html
  return div.textContent || ''
}

export function highlight(text: string, query: string): string {
  if (!query.trim()) return text
  const esc = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const re = new RegExp(`(${esc})`, 'gi')
  return text.replace(re, '<mark>$1</mark>')
}
