
import Dexie, { Table } from 'dexie'

export interface Note {
  id: string
  title: string
  html: string
  tags: string[]
  createdAt: number
  updatedAt: number
}

export class NotesDB extends Dexie {
  notes!: Table<Note, string>

  constructor() {
    super('notes-lite')
    this.version(1).stores({
      notes: 'id, title, updatedAt, createdAt' // indexes
    })
  }
}

export const db = new NotesDB()
