
import React from 'react'

export function SearchBar({value, onChange, placeholder='Поиск...'}: {
  value: string
  onChange: (v: string) => void
  placeholder?: string
}){
  return (
    <div className="search">
      <span>🔎</span>
      <input value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} />
    </div>
  )
}
