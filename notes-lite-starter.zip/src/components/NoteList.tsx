
import React from 'react'
import { Note } from '../db'
import { highlight } from '../utils'

export function NoteList({
  notes, activeId, onOpen, query, tagFilter
}: {
  notes: Note[]
  activeId?: string
  onOpen: (id: string) => void
  query: string
  tagFilter: string | null
}){
  return (
    <div className="note-list">
      {notes.map(n => {
        const snippet = (n.title + ' ' + n.html.replace(/<[^>]+>/g,' ')).slice(0, 160)
        const matchesTag = tagFilter ? n.tags.includes(tagFilter) : true
        if (!matchesTag) return null
        return (
          <div key={n.id} className={"note-item " + (n.id === activeId ? 'active' : '')} onClick={()=>onOpen(n.id)}>
            <div className="note-title" dangerouslySetInnerHTML={{__html: highlight(n.title || 'Без названия', query)}} />
            <div className="note-snippet" dangerouslySetInnerHTML={{__html: highlight(snippet, query)}} />
            {n.tags.length ? <div className="tags">
              {n.tags.map(t => <span className="tag" key={t}>#{t}</span>)}
            </div> : null}
          </div>
        )
      })}
    </div>
  )
}
