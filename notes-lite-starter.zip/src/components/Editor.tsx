
import React, { useEffect, useRef, useState } from 'react'
import { extractTags, extractWikiLinks } from '../utils'
import { db, Note } from '../db'

function exec(cmd: string, val?: string){
  document.execCommand(cmd, false, val)
}

function ensureParagraphAtEnd(el: HTMLElement){
  if (!el.lastChild || el.lastChild.nodeName === '#text') {
    const p = document.createElement('p')
    p.appendChild(document.createElement('br'))
    el.appendChild(p)
  }
}

export function Editor({
  note, onChange
}: {
  note: Note
  onChange: (n: Partial<Note>) => void
}){
  const titleRef = useRef<HTMLInputElement>(null)
  const editorRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = note.html || '<p><br></p>'
    }
  }, [note.id])

  const onInput = () => {
    const html = editorRef.current?.innerHTML || ''
    const text = editorRef.current?.textContent || ''
    const tags = extractTags((note.title || '') + ' ' + text)
    onChange({ html, tags })
  }

  const handleKeyDown: React.KeyboardEventHandler<HTMLDivElement> = (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'b') { exec('bold'); e.preventDefault(); }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'i') { exec('italic'); e.preventDefault(); }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'u') { exec('underline'); e.preventDefault(); }
  }

  const makeList = (ordered=false) => {
    exec(ordered ? 'insertOrderedList' : 'insertUnorderedList')
  }

  const insertCheckbox = () => {
    // simple checkbox as [ ] item: insert an unchecked box character ☐/☑
    const sel = window.getSelection()
    if (!sel || !sel.rangeCount) return
    const span = document.createElement('span')
    span.textContent = '☐ '
    sel.getRangeAt(0).insertNode(span)
    sel.collapseToEnd()
    onInput()
  }

  const wrapHeading = (level: number) => {
    exec('formatBlock', 'H' + level)
  }

  const wrapParagraph = () => exec('formatBlock', 'P')

  // Simple WikiLink preview: detect [[Title]] and underline it
  useEffect(() => {
    const el = editorRef.current!
    const obs = new MutationObserver(() => {
      // Replace [[text]] with underlined span for UX
      const html = el.innerHTML
      const replaced = html.replace(/\[\[([^\]]+)\]\]/g, '<u data-wikilink="$1">[[\$1]]</u>')
      if (replaced !== html) {
        const pos = window.getSelection()?.getRangeAt(0)
        el.innerHTML = replaced
        // naive: move caret to end
        const range = document.createRange()
        range.selectNodeContents(el)
        range.collapse(false)
        const sel = window.getSelection()
        sel?.removeAllRanges()
        sel?.addRange(range)
        onInput()
      }
    })
    obs.observe(el, { childList: true, subtree: true, characterData: true })
    return () => obs.disconnect()
  }, [])

  return (
    <div className="editor-wrap">
      <input
        ref={titleRef}
        className="title-input"
        value={note.title}
        onChange={e=>onChange({title: e.target.value})}
        placeholder="Заголовок"
      />
      <div className="meta">
        Обновлено: {new Date(note.updatedAt).toLocaleString()} · Теги: {note.tags.map(t=>'#'+t).join(' ') || '—'}
      </div>
      <div className="toolbar">
        <button onClick={()=>wrapHeading(1)}>H1</button>
        <button onClick={()=>wrapHeading(2)}>H2</button>
        <button onClick={()=>wrapHeading(3)}>H3</button>
        <button onClick={wrapParagraph}>Параграф</button>
        <button onClick={()=>exec('bold')}><b>B</b></button>
        <button onClick={()=>exec('italic')}><i>I</i></button>
        <button onClick={()=>exec('underline')}><u>U</u></button>
        <button onClick={()=>exec('strikeThrough')}><s>S</s></button>
        <button onClick={()=>makeList(false)}>• Список</button>
        <button onClick={()=>makeList(true)}>1. Список</button>
        <button onClick={insertCheckbox}>☐ Чекбокс</button>
      </div>
      <div
        ref={editorRef}
        className="editor"
        contentEditable
        suppressContentEditableWarning
        onInput={onInput}
        onKeyDown={handleKeyDown}
      ></div>
    </div>
  )
}
